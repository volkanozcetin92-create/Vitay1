# VITAY Tokenomics

MAX_SUPPLY = 10,550,000 VITAY

MINING_POOL = 2,110,000 = 20%
REWARD_POOL = 527,500 = 5%
GENESIS_MINT = 10,550,000 - 2,110,000 - 527,500 = 7,912,500 = 75%

Genesis:
- FOUNDER: 1,055,000 (10%)
- COMMUNITY: 2,637,500 (25%)
- DEVELOPMENT: 1,582,500 (15%)
- LIQUIDITY: 1,055,000 (10%)
- RESERVE: 1,055,000 (10%)
- PROMOTION: 527,500 (5%)

Genesis total = 7,912,500 (75%)
All pools = 10,550,000 (100%)

This is a supply/distribution formula, not a price formula. Market price cannot be guaranteed or predetermined by the code.
