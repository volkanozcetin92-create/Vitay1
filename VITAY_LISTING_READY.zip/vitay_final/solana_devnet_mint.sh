#!/usr/bin/env bash
set -euo pipefail

# VITAY — Solana Devnet mint preparation
# Devnet only. Never place a private key/seed phrase in this file.

MINT_DECIMALS=6

solana config set --url devnet
solana config get

printf '\n[1/4] Devnet wallet address:\n'
solana address

printf '\n[2/4] Checking Devnet balance:\n'
solana balance

printf '\n[3/4] Creating VITAY mint (6 decimals):\n'
MINT=$(spl-token --url devnet create-token --decimals "$MINT_DECIMALS" | awk '/Creating token/ {print $3}')
if [[ -z "${MINT}" ]]; then
  echo "Mint address could not be parsed. Run: spl-token --url devnet create-token --decimals 6"
  exit 1
fi

echo "VITAY_MINT=$MINT"
printf '%s\n' "$MINT" > vitay_mint_address.txt

printf '\n[4/4] Creating associated token account:\n'
TOKEN_ACCOUNT=$(spl-token --url devnet create-account "$MINT" | awk '/Creating account/ {print $3}')
echo "VITAY_TOKEN_ACCOUNT=$TOKEN_ACCOUNT"
printf '%s\n' "$TOKEN_ACCOUNT" > vitay_token_account.txt

printf '\nMint verification:\n'
spl-token --url devnet supply "$MINT"
spl-token --url devnet display "$MINT"

cat <<EOT

VITAY Devnet mint prepared.
Mint address: $MINT
Token account: $TOKEN_ACCOUNT

IMPORTANT:
- This is a Devnet token and has no financial value.
- The mint starts with zero supply.
- Do not publish private keys or seed phrases.
- Do not mint the full VITAY supply from this script; supply allocation should be enforced separately.
EOT
