# VITAY Mainnet Checklist

- [ ] Legal classification/review completed
- [ ] Public token documentation completed
- [ ] Final token program and extensions selected
- [ ] Mainnet deployment wallet created and secured externally
- [ ] Devnet end-to-end test passed
- [ ] Independent code/security review completed
- [ ] Mainnet mint created
- [ ] Mint address independently verified
- [ ] Decimals verified
- [ ] Maximum supply verified
- [ ] Mint authority policy verified
- [ ] Freeze authority policy verified
- [ ] Metadata verified
- [ ] Allocation addresses published
- [ ] Vesting/lockups documented where applicable
- [ ] Exchange/platform application requirements reviewed
- [ ] No claim of guaranteed listing or guaranteed value

Do not publish a fake or placeholder mint address as a real VITAY contract address.
