import base64, json, os, hashlib
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .crypto import generate_keypair

def _key(password,salt): return hashlib.scrypt(password.encode(),salt=salt,n=2**14,r=8,p=1,dklen=32)
def create_wallet(password):
    sk,address=generate_keypair(); raw=sk.private_bytes_raw()
    return {'address':address,'private_key':raw.hex(),'password':password}
def save_wallet(w,path):
    salt=os.urandom(16); nonce=os.urandom(12); key=_key(w['password'],salt); ct=AESGCM(key).encrypt(nonce,bytes.fromhex(w['private_key']),None)
    data={'version':1,'address':w['address'],'kdf':'scrypt','salt':base64.b64encode(salt).decode(),'nonce':base64.b64encode(nonce).decode(),'ciphertext':base64.b64encode(ct).decode()}
    with open(path,'w',encoding='utf-8') as f: json.dump(data,f,separators=(',',':'))
    os.chmod(path,0o600)
def load_wallet(path,password):
    with open(path,encoding='utf-8') as f: data=json.load(f)
    salt=base64.b64decode(data['salt']); nonce=base64.b64decode(data['nonce']); ct=base64.b64decode(data['ciphertext']); raw=AESGCM(_key(password,salt)).decrypt(nonce,ct,None)
    sk=Ed25519PrivateKey.from_private_bytes(raw); return {'address':sk.public_key().public_bytes_raw().hex(),'private_key':raw.hex(),'password':password}
