import json
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

def canonical_bytes(obj):
    return json.dumps(obj, sort_keys=True, separators=(',',':'), ensure_ascii=False).encode('utf-8')

def generate_keypair():
    sk=Ed25519PrivateKey.generate(); pk=sk.public_key()
    raw=pk.public_bytes_raw(); return sk, raw.hex()

def sign(sk, msg):
    if isinstance(sk, bytes):
        sk=Ed25519PrivateKey.from_private_bytes(sk)
    return sk.sign(msg).hex()

def verify(address, signature, msg):
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(address)).verify(bytes.fromhex(signature), msg); return True
    except Exception: return False
