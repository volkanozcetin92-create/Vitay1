# VITAY — Solana Devnet Mint

This folder contains the Devnet mint preparation script for VITAY.

## Parameters

- Network: Solana Devnet
- Token: VITAY
- Symbol: VITAY
- Decimals: 6
- Target maximum supply in the VITAY project: 10,550,000 VITAY

## Important distinction

The existing `vitay.py` is the project's standalone educational chain/core. A Solana SPL mint is a separate on-chain representation. Creating the Devnet mint does not automatically enforce the Python chain's tokenomics.

## Create the Devnet mint

Use a Devnet-only signer/wallet. Never paste a seed phrase or private key into chat or source files.

```bash
./solana_devnet_mint.sh
```

The script saves the generated mint address to `vitay_mint_address.txt` and the associated token account to `vitay_token_account.txt`.

If the CLI is not installed, use the official Solana documentation or Solana Playground.

## Verification

After creation:

```bash
spl-token --url devnet supply <MINT_ADDRESS>
spl-token --url devnet display <MINT_ADDRESS>
```

A new mint begins with zero supply. Tokens can only be minted by the mint authority. For a genuinely fixed supply, the mint authority can later be disabled, but that is an irreversible authority change and should only be done after the final supply is verified.
