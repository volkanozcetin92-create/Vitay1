# VITAY

VITAY is an educational Solana Devnet project.

## Current configuration

- Network: Solana Devnet
- Maximum supply: 10,550,000 VITAY
- Decimals: 9
- Mint address: not configured yet

No private keys or production credentials are stored in this repository.

## Test

    python -m pytest -q
