import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from main import load_config, validate_config


def test_vitay_config():
    assert validate_config(load_config()) is True
