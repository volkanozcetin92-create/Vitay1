import json
from pathlib import Path

CONFIG_PATH = Path(__file__).with_name("vitay_config.json")


def load_config():
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def validate_config(config):
    assert config["name"] == "VITAY"
    assert config["network"] == "devnet"
    assert config["rpc_url"] == "https://api.devnet.solana.com"
    assert config["max_supply"] == 10_550_000
    assert isinstance(config["decimals"], int)
    assert 0 <= config["decimals"] <= 9
    return True


if __name__ == "__main__":
    validate_config(load_config())
    print("VITAY configuration OK (Solana Devnet).")
