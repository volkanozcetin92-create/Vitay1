export type Contributor = {
  name: string;
  role: string;
};

export const contributors: Contributor[] = [];
